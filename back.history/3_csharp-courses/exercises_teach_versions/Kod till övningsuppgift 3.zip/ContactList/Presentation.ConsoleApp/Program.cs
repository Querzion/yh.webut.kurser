﻿
using Presentation.ConsoleApp.Diloags;

var dialog = new MenuDialog();
dialog.ShowMenu();