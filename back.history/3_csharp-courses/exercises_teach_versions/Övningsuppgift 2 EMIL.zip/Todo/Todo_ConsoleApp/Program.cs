﻿using Todo_ConsoleApp.Services;

var mainMenu = new MenuService();
mainMenu.ShowMainMenu();
