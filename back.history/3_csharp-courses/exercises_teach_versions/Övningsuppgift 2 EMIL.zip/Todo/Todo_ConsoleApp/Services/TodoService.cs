﻿using Todo_ConsoleApp.Models;

namespace Todo_ConsoleApp.Services;

public class TodoService
{
    private readonly List<TodoModel> _todos = [];

    // Lägga till todo

    public void AddTodoItem(TodoModel todo)
    {
        // Förenklad if sats
        // Detta är som att vi använder autouncrement i en databas

        todo.Id = _todos.Count > 0 ? _todos[^1].Id + 1 : 1;
        _todos.Add(todo);
        
    }


    // Visa alla todo

    public IEnumerable<TodoModel> GetAllTodoItems()
    {
        return _todos;
    }

    // Uppdatera todo

    public bool UpdateTodoItem(int id)
    {
        var todoToUpdate = _todos.FirstOrDefault(todo => todo.Id == id);
        if (todoToUpdate != null) 
        {
            todoToUpdate.IsCompleted = true;
            return true;
        }
        return false;
    }

}