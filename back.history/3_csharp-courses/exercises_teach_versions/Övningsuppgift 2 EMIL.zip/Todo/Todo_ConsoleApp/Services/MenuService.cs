﻿using Todo_ConsoleApp.Models;

namespace Todo_ConsoleApp.Services;

public class MenuService
{
    private readonly TodoService _todoService = new();


    public void ShowMainMenu()
    {
        bool isRunning = true;

        do
        {
            Console.Clear();
            Console.WriteLine("------- TODO LIST --------");
            Console.WriteLine("1. Add new Todo");
            Console.WriteLine("2. View All Todos");
            Console.WriteLine("Q. Exit Application");
            Console.WriteLine("---------------------------");
            Console.Write("Enter option: ");
            string option = Console.ReadLine()!;

            switch (option.ToLower())
            {
                case "1":
                    ShowAddTodo();
                    break;

                case "2":
                    ShowAllTodos();
                    break;

                case "q":
                    Console.Clear();
                    Console.WriteLine("Press any key to exit application");
                    Console.ReadKey();
                    isRunning = false;
                    break;

                default:
                    InvalidOption("Invalid option. Please try again.");
                    break;
            }


        } while (isRunning);

    }

    public void ShowAddTodo()
    {
        var todoModel = new TodoModel();

        Console.Clear();
        Console.WriteLine("------- NEW TODO --------");
        Console.Write("Enter new todo: ");

        todoModel.Description = Console.ReadLine()!;

        _todoService.AddTodoItem(todoModel);

    }

    public void ShowAllTodos()
    {
        var todos = _todoService.GetAllTodoItems();

        Console.Clear();
        Console.WriteLine("------- ALL TODOS --------");

        foreach (var todosItem in todos)
        {
            var status = todosItem.IsCompleted ? "Completed" : "Un Completed";
            Console.WriteLine($"#{todosItem.Id} :: {todosItem.Description} ({status})");
        }

        Console.WriteLine();
        Console.Write("Enter 'Id' to mark a todo as completed, else press 'Enter' to go back: ");

        var option = Console.ReadLine();

        // Kontrollera om användaren bara tryckte på Enter
        if (string.IsNullOrWhiteSpace(option))
        {
            // Avsluta metoden
            return; 
        }

        if (int.TryParse(option, out int id))
        {
            _todoService.UpdateTodoItem(id);
            ShowAllTodos();
        }
        else
        {
            InvalidOption("Invalid input. Press any key to try again");
            ShowAllTodos();
        }
    }

    public void InvalidOption(string message)
    {
        Console.Clear();
        Console.WriteLine(message);
        Console.ReadKey();
    }

}
