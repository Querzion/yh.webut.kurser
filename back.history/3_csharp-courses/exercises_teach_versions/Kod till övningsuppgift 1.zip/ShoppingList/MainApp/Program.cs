﻿List<string> shoppingList = [];

while(true)
{
    Console.Clear();
    Console.Write("Ange en vara: ");
    string item = Console.ReadLine()!;

    if (string.IsNullOrWhiteSpace(item))
    {
        Console.Write("Du måste ange en vara. Tryck på valfri tangent för att fortsätta.");
        Console.ReadKey();
    }
    else if (item.Equals("klar", StringComparison.OrdinalIgnoreCase))
    {
        break;
    }
    else if (item.Equals("grass", StringComparison.OrdinalIgnoreCase))
    {
        Console.Write($"{item} är inte lagligt. Fy fy på dig!. Tryck på valfri tangent för att fortsätta.");
        Console.ReadKey();
    }
    else
    {
        shoppingList.Add(item);
        Console.Write($"{item} har lagts till i listan. Tryck på valfri tangent för att fortsätta.");
        Console.ReadKey();
    }
}

Console.Clear();
Console.WriteLine("Shoppinglista:");

foreach (var item in shoppingList)
{
    Console.WriteLine($"- {item}");
}

Console.ReadKey();