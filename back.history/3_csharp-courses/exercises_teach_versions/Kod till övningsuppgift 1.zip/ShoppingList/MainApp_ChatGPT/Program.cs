﻿var shoppingList = new List<string>();

while (true)
{
    Console.Clear();
    Console.Write("Ange en vara (skriv 'klar' för att avsluta): ");
    var item = Console.ReadLine()?.Trim();

    if (string.IsNullOrEmpty(item))
    {
        Console.Write("Du måste ange en vara. Tryck på valfri tangent för att fortsätta.");
    }
    else if (item.Equals("klar", StringComparison.OrdinalIgnoreCase))
    {
        break;
    }
    else if (item.Equals("grass", StringComparison.OrdinalIgnoreCase))
    {
        Console.Write($"{item} är inte lagligt. Fy fy på dig!. Tryck på valfri tangent för att fortsätta.");
    }
    else
    {
        shoppingList.Add(item);
        Console.Write($"{item} har lagts till i listan. Tryck på valfri tangent för att fortsätta.");
    }

    Console.ReadKey();
}

Console.Clear();
Console.WriteLine("Shoppinglista:");
shoppingList.ForEach(item => Console.WriteLine($"- {item}"));

Console.ReadKey();