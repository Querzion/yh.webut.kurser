﻿using Business.Interfaces;

namespace Business.Services;

public class FileService(string directoryPath, string fileName) : IFileService
{
    private readonly string _directoryPath = directoryPath;
    private readonly string _filePath = Path.Combine(directoryPath, fileName);

    public string GetContentFromFile()
    {
        if (File.Exists(_filePath))
            return File.ReadAllText(_filePath);

        return null!;
    }

    public bool SaveContentToFile(string content)
    {
        try
        {
            if (!Directory.Exists(_directoryPath))
                Directory.CreateDirectory(_directoryPath);

            File.WriteAllText(_filePath, content);

            return true;
        }

        catch { }
        return false;
    }
}
