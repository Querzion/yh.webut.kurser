﻿using Business.Converters;
using Business.Interfaces;
using Business.Models;
using System.Text.Json;

namespace Business.Services;

public class UserService(IFileService fileService) : IUserService
{
    private readonly IFileService _fileService = fileService;
    private List<UserBase> _users = [];

    private readonly JsonSerializerOptions _serializerOptions = new()
    {
        Converters = { new UserBaseJsonConverter() },
        WriteIndented = true,  
    };

    public bool AddUser(UserBase user)
    {
        try
        {
            user.Id = _users.Count != 0 ? _users.Last().Id + 1 : 1;
            _users.Add(user);

            SaveUsersListToFile();
            return true;
        }
        catch
        {
            return false;
        }
    }

    public IEnumerable<UserBase> GetAllUsers()
    {
        PopulateUsersFromFile();
        return _users;
    }

    public UserBase? GetUserById(int id)
    {
        PopulateUsersFromFile();
        var user = _users.FirstOrDefault(user => user.Id == id);
        return user;
    }


    public void PopulateUsersFromFile()
    {
        var json = _fileService.GetContentFromFile();
        if (!string.IsNullOrEmpty(json))
            _users = JsonSerializer.Deserialize<List<UserBase>>(json, _serializerOptions)!;
    }

    public void SaveUsersListToFile()
    {
        var json = JsonSerializer.Serialize(_users, _serializerOptions);
        _fileService.SaveContentToFile(json);
    }
}
