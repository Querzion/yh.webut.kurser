﻿using Business.Models;

namespace Business.Interfaces;

public interface IUserService
{
    bool AddUser(UserBase user);
    IEnumerable<UserBase> GetAllUsers();
    UserBase? GetUserById(int id);
}
