﻿using Business.Interfaces;
using Business.Models;


namespace MainApp.Dialogs;

public class MenuDialog(IUserService userService)
{
    private readonly IUserService _userService = userService;


    public void ViewAllUsers()
    {
        Console.WriteLine();
        Console.WriteLine("----- VISA ALLA ANVÄNDARE -----");

        foreach( var user in _userService.GetAllUsers())
            Console.WriteLine($"{user.Name} ({user.GetRole()})");

        Console.ReadKey();
    }


    public void CreateRegularUser()
    {
        var user = new RegularUser();

        Console.Clear();
        Console.WriteLine("----- NY REGULAR ANVÄNDARE -----");
        Console.Write("Ange ett namn: ");
        user.Name = Console.ReadLine()!;

        _userService.AddUser(user);
    }

    public void CreateAdminUser()
    {
        var user = new AdminUser();

        Console.Clear();
        Console.WriteLine("----- NY ADMIN ANVÄNDARE -----");
        Console.Write("Ange ett namn: ");
        user.Name = Console.ReadLine()!;

        _userService.AddUser(user);
    }
}
