﻿using Business.Interfaces;
using Business.Models;
using Business.Services;
using Moq;

namespace Business.Tests.Services;

public class UserService_Tests
{
	private readonly Mock<IFileService> _fileServiceMock;
	private readonly IUserService _userService;
	public UserService_Tests()
	{
		_fileServiceMock = new Mock<IFileService>();
		_userService = new UserService(_fileServiceMock.Object);
	}

	[Fact]
	public void AddUser_ShoudReturnTrue_WhenUserIsAddedToList()
	{
		// Arrange
		var user = new RegularUser();
		_fileServiceMock.Setup(fs => fs.SaveContentToFile(It.IsAny<string>()));

		// Act
		var result = _userService.AddUser(user);

		// Assert
		Assert.True(result);
	}

}
