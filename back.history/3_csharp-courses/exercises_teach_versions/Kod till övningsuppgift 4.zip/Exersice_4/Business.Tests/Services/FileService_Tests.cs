﻿using Business.Interfaces;
using Business.Models;
using Moq;
using System.Text.Json;

namespace Business.Tests.Services;

public class FileService_Tests
{
    private readonly Mock<IFileService> _fileServiceMock;

    public FileService_Tests()
    {
        _fileServiceMock = new Mock<IFileService>();
    }

    [Fact]
    public void SaveContentToFile_ShouldReturnTrue()
    {
        // Arrange 
        _fileServiceMock.Setup(fs => fs.SaveContentToFile(It.IsAny<string>())).Returns(true);

        // Act
        var result = _fileServiceMock.Object.SaveContentToFile("");

        // Assert
        Assert.True(result);
    }
}
