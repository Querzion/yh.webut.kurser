﻿using MainApp.Models;

namespace MainApp.Factories;

public static class TodoItemFactory
{
    public static TodoItem Create()
    {
        return new TodoItem();
    } 
}
