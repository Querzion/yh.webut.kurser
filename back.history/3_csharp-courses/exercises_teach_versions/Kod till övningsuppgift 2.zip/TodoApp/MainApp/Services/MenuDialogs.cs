﻿using MainApp.Factories;

namespace MainApp.Services;

public class MenuDialogs
{
    private readonly TodoService _todoService = new TodoService();

    public void ShowMenuOptions()
    {
        var isRunning = true;

        do
        {
            Console.Clear();
            Console.WriteLine("-------- TODO LIST --------");
            Console.WriteLine("1. Add New Todo Item");
            Console.WriteLine("2. View All Todo Items");
            Console.WriteLine("Q. Exit Application");
            Console.WriteLine("---------------------------");
            Console.Write("Enter option: ");
            string option = Console.ReadLine()!;

            switch (option.ToUpper())
            {
                case "1":
                    ShowAddNewTodoItemOption();
                    break;

                case "2":
                    ShowViewAllTodoItemsOption();
                    break;

                case "Q":
                    Console.Clear();
                    OutputDialog("Press any key to exit application.");
                    isRunning = false;
                    break;

                default:
                    OutputDialog("Invalid option. Please try again.");
                    break;
            }
        }
        while (isRunning);
    }
    
    public void OutputDialog(string message)
    {
        Console.Write(message);
        Console.ReadKey();
    }


    public void ShowAddNewTodoItemOption()
    {
        var todoItem = TodoItemFactory.Create();
        
        Console.Clear();
        Console.WriteLine("-------- NEW TODO ITEM --------");
        Console.Write("Enter activity: ");
        todoItem.Description = Console.ReadLine()!;

        _todoService.AddTodoItem(todoItem);
    }


    public void ShowViewAllTodoItemsOption()
    {
        var todoItems = _todoService.GetAllTodoItems();

        Console.Clear();
        Console.WriteLine("-------- VIEW ALL TODO ITEMS --------");

        foreach (var todoItem in todoItems)
        {
            var state = todoItem.IsCompleted ? "slutförd" : "pågående";
            Console.WriteLine($"#{todoItem.Id} :: {todoItem.Description} ({state})");
        }

        if (todoItems.Count() == 0)
        {
            Console.Write("\nPress 'enter' to go back: ");
            Console.ReadKey();
        }    
        else
        {
            Console.Write("\nEnter 'Id' to mark a todo item as completed, else press 'enter' to go back: ");
            var option = Console.ReadLine();

            if (!string.IsNullOrEmpty(option))
            {
                if (int.TryParse(option, out int id))
                {
                    _todoService.UpdateTodoItem(id);
                }

                ShowViewAllTodoItemsOption();
            }
        }

    }
}
