﻿using MainApp.Models;

namespace MainApp.Services;

public class TodoService
{
    private List<TodoItem> _todoItems = [];

    public void AddTodoItem(TodoItem item)
    {
        item.Id = _todoItems.Count > 0 ? _todoItems[^1].Id + 1 : 1;
        _todoItems.Add(item);
    }

    public IEnumerable<TodoItem> GetAllTodoItems()
    {
        return _todoItems;
    }

    public void UpdateTodoItem(int id)
    {
        var todoItem = _todoItems.FirstOrDefault(x => x.Id == id);
        if (todoItem != null)
            todoItem.IsCompleted = true;
    }
}
