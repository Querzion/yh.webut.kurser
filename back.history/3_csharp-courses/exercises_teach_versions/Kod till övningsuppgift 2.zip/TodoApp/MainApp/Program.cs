﻿using MainApp.Services;


var menu = new MenuDialogs();
menu.ShowMenuOptions();